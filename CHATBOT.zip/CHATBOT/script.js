// Replace with your actual API key
const API_KEY = "AIzaSyDcA0r11_OFmxB4gcJKu9L5kTO0yLrYpsI";
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${API_KEY}`;

const chatMessages = document.getElementById('chat-messages');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');

// Add event listeners
sendButton.addEventListener('click', sendMessage);
userInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

// Initial greeting
addBotMessage("Hello! I'm your Gemini assistant. How can I help you today?");

function sendMessage() {
    const message = userInput.value.trim();
    if (message === '') return;
    
    addUserMessage(message);
    userInput.value = '';
    
    // Show loading indicator
    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'message bot-message';
    loadingDiv.innerHTML = '<div class="loading"></div>';
    chatMessages.appendChild(loadingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    // Call Gemini API
    fetch(API_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            contents: [{
                parts: [{
                    text: message
                }]
            }]
        })
    })
    .then(response => response.json())
    .then(data => {
        // Remove loading indicator
        chatMessages.removeChild(loadingDiv);
        
        if (data.candidates && data.candidates[0].content.parts[0].text) {
            const botResponse = data.candidates[0].content.parts[0].text;
            addBotMessage(botResponse);
        } else {
            addBotMessage("Sorry, I couldn't process your request. Please try again.");
        }
    })
    .catch(error => {
        console.error('Error:', error);
        chatMessages.removeChild(loadingDiv);
        addBotMessage("Sorry, there was an error processing your request.");
    });
}

function addUserMessage(text) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message user-message';
    messageDiv.textContent = text;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function addBotMessage(text) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message bot-message';
    messageDiv.textContent = text;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}